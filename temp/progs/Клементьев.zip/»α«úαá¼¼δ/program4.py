num = float(input("Введите число: "))

for i in range(1, 6):
    print("{} в степени {} = {}".format(num, i, num ** i))
